import geocoder
from gmplot import gmplot

address = "Cardiff, 2A, Oak Tree Court Mulberry Drive, Cardiff Gate Business Park"

# Geocode the address to get the coordinates
location = geocoder.osm(address)

if location.ok:
    # Retrieve latitude and longitude
    lat, lng = location.lat, location.lng

    # Create an instance of gmplot
    gmap = gmplot.GoogleMapPlotter(lat, lng, zoom=13)

    # Mark the location on the map
    gmap.marker(lat, lng, title=address)

    # Generate the iframe code
    iframe_code = gmap.get_iframe()

    print("Google Maps iframe code:")
    print(iframe_code)
else:
    print("Address not found.")
