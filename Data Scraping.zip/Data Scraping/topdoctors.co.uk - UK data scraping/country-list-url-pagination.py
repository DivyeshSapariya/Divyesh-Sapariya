import mechanicalsoup, re, requests, csv
from datetime import datetime
# import traceback

browser     = mechanicalsoup.Browser()
session     = requests.Session()
FileName    = datetime.today().strftime('%Y-%m-%d')

def get_scrapped_url_lists():
    with open('urls.txt','r') as f:
        return [x.replace('\n','') for x in f.readlines()]

def save_scrapped_url_lists(urls):
    with open('urls.txt','a') as f:
        f.write(urls)
        f.write('\n')

def get_scrapped_doctors_lists():
    with open('doctors.txt','r') as f:
        return [x.replace('\n','') for x in f.readlines()]


def save_scrapped_doctors_lists(urls):
    with open('doctors.txt','a') as f:
        f.write(urls)
        f.write('\n')

def AddItemCSV( data, filename = 'all-list' ):
    with open( './data/' + filename + '.csv', 'a', encoding='UTF-8', newline='') as f:
        print('Update CSV File')
        writer = csv.writer(f)
        writer.writerows(data) # write multiple rows


CSVList = {}
lists   = get_scrapped_url_lists()
doctors = get_scrapped_doctors_lists()

for link in lists:
    CountryName = 'uk'
    page        = browser.get(link)
    LimitEntry = 500
    FileNo = 1
    LoopNoCount = 1

    for i in range( 179, 203 ):
        print(" ")
        print(link + 'page/' + str(i))
        InnerPage    = browser.get( link + 'page/' + str(i) )
        for RowSearch in InnerPage.soup.select("section.item.bg_paper.bottom_margin"):       
            for InRow in RowSearch.select('a.h3.item_name'):
                if InRow.get('href') not in doctors:
                    try:
                        SinglePg    = browser.get( 'https://www.topdoctors.co.uk' + InRow.get('href') )
                        print( " " )
                        # print( 'https://www.topdoctors.co.uk' + InRow.get('href') )   
                        save_scrapped_doctors_lists( 'https://www.topdoctors.co.uk' + InRow.get('href') )
                        CSVList = { 
                            'Name'              : '',
                            'Skip1'             : '',
                            'experience'        : '',
                            'Skip2'             : '',
                            'city'              : '',
                            'Skip3'             : '',
                            'Images'            : '',
                            'Skip4'             : '',
                            'sectionAbout'      : '',
                            'Skip5'             : '',
                            'specialities'      : '',
                            'Skip6'             : '',
                            'workExperience'    : '',
                            'Skip7'             : ''
                        }

                        # for item in SinglePg.soup.select('div#doctor-search'):
                        #     item.extract()

                        # done
                        CSVList['Name'] = ''
                        for item in RowSearch.select('span[itemprop="name"]'):
                            CSVList['Name'] = str( (item.text).strip() )
                        
                        CSVList['Skip1'] = 12
                        
                        # done
                        CSVList['experience'] = ''
                        for item in SinglePg.soup.select('p#cv_list_doctor_1'):
                            experience_text = item.find('big').find_next_sibling(string=True).strip()
                            if experience_text:
                                CSVList['experience'] = experience_text
                            else:
                                CSVList['experience'] = 'Not Available'

                        
                        CSVList['Skip2'] = 12
                        
                        # done - 
                        CSVList['city'] = ''
                        for item in SinglePg.soup.select("h2.limited-qualifications > a:last-child"):
                            CSVList['city'] = str( (item.text).strip() )                       

                        
                        CSVList['Skip3'] = 12

                        # done
                        CSVList['Images'] = ''
                        hospimg = ''
                        for item in SinglePg.soup.select("img.photo_premium_item"):
                            hospimg += "https://www.topdoctors.co.uk/" + item.get('src')

                        CSVList['Images'] = str( hospimg )
                        
                        CSVList['Skip4'] = 12
                        
                        # done
                        CSVList['sectionAbout'] = ''
                        for item in SinglePg.soup.select('p[itemprop="description"]'):
                            CSVList['sectionAbout'] = str( item )

                        for item in SinglePg.soup.select("p#cv_list_doctor_3"):
                            CSVList['sectionAbout'] += '<h2>Education</h2>' + str( item )
                        
                        CSVList['Skip5'] = 12

                        CSVList['specialities'] = ''
                        for item in SinglePg.soup.select("p#cv_list_doctor_2"):
                            experience_text = str( item )
                            if experience_text:
                                CSVList['specialities'] = experience_text
                            else:
                                CSVList['specialities'] = 'Not Available'

                        CSVList['Skip6'] = 12

                        # done
                        CSVList['workExperience'] = ''
                        for item in SinglePg.soup.select('p#cv_list_doctor_1'):
                            experience_text = str( item )
                            if experience_text:
                                CSVList['workExperience'] = experience_text
                            else:
                                CSVList['workExperience'] = 'Not Available'

                        CSVList['Skip7'] = 12


                        AddRowList = []
                        for InCols in CSVList:
                            AddRowList.append(CSVList[InCols] )
                            
                        try:
                            print( 'Update Counts :: ' + str( ' ' ) + str(LimitEntry) + str( ' ' ) + str(FileNo) + str( ' ' ) + str(LoopNoCount) )
                            if( LoopNoCount == LimitEntry ):
                                LimitEntry += 500
                                FileNo += 1

                            AddItemCSV( [ list(AddRowList) ], CountryName + str('-') + str(FileNo) )

                            LoopNoCount += 1
                        except Exception as e:
                            print('Not Inserted In CSV File Data :: ' + str(InRow.get('href')) )
                            # print("An error occurred:", str(e))
                    except Exception as e:
                        print( 'Something wrong....' )
                        # print("An error occurred:", str(e))
                        # traceback.print_exc()