jQuery(document).ready(function() {

  function filter_data() {
      let CatLists = '';
      var dataArrary = [];
      let keyword = jQuery('.cff_search-input').val();

      jQuery('.less-topic-cat-filter').each(function(index, value) {
          var rowArray = [];
          jQuery(jQuery(value).val()).each(function(i, val) {
              CatLists += val;
              rowArray.push(val);
          });
          if (rowArray.length > 0) {
              dataArrary.push(rowArray);
          }
      });

      $.ajax({
          url: ajaxurl,
          type: 'POST',
          data: {
              action: 'cff_learndash_get_lesson_topics',
              catFilter: dataArrary,
              keyword: keyword
          },
          success: function(response) {
              jQuery('.cff_lesson-topics.isotope').empty();
              jQuery('.cff_lesson-topics.isotope').append(response);
          }
      });
  }

  jQuery('.less-topic-cat-filter').each(function(index, value) {
      jQuery('.' + jQuery(value).attr('data-selectid')).on('change', function(e) {
          filter_data();
      });
  });

  var $quicksearch = jQuery('.cff_search-input').keyup( function() {
      filter_data();
  });

  jQuery('.less-topic-cat-filter').each(function(index, value) {
    let defaultSet = ' Select ' + jQuery(value).attr('data-defaultsel');

    jQuery(this).multiSelect({
        'noneText': defaultSet,
      }
    );
  }); 
});