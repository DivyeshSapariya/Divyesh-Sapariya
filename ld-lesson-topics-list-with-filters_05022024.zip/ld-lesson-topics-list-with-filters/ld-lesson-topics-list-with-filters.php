<?php

/**
 * Plugin Name: LD Lesson Topics List With Filter
 * 
 */

add_action('wp_enqueue_scripts', 'cff_enqueue_styles');
function cff_enqueue_styles(){
    wp_enqueue_script('multiselect-filter', '/wp-content/plugins/ld-lesson-topics-list-with-filters/jquery.multi-select.js', array('jquery'), '', true);

    wp_enqueue_script( 'cff', plugin_dir_url( __FILE__ ) . '/ld-lesson-topic-list-filters.js', array('jquery'), '1.0', true );
    wp_localize_script( 'cff', 'my_ajax_object', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
}

function cff_learndash_lesson_topics_shortcode($atts)
{

    ob_start();

    $atts = shortcode_atts(array(
        'lesson_id' => 0,
        'category_ids' => '',
    ), $atts, 'learndash_lesson_topics');

    $lesson_id      = absint($atts['lesson_id']);
    $category_ids   = explode(',', $atts['category_ids']);

    if (class_exists('SFWD_LMS')) {
        $topics = cff_learndash_get_lesson_topics_list($lesson_id);

        echo '<div class="main-lesson-topic learndash">';
        echo '<form class="lesson-topic-search-form">';
            echo '<input type="text" name="search" class="cff_search-input" placeholder="Search topics" value="">';

            $catDrp = '';
            if (!empty($category_ids)) {

                foreach ($category_ids as $idCatKey => $idCatVal) {
                    $parent_category = get_term_by('id', $idCatVal, 'ld_topic_category', 'ARRAY_A');

                    $catDrp .= '<select multiple name="less-topics-cat" data-defaultsel="' . $parent_category['name'] . '" class="less-topic-cat-filter select-id-' . $idCatVal . '" data-selectid="select-id-' . $idCatVal . '">';
//                     $catDrp .= '<option value=""> Select ' . $parent_category['name'] . '</option>';

                    if (!empty($parent_category)) {
                        $catDrp .= sprintf(
                            '<option value="%s">%s</option>',
                            '.' . $parent_category['slug'],
                            $parent_category['name']
                        );
                    }

                    $categories = get_terms(array(
                        'taxonomy'      => 'ld_topic_category',
                        'hide_empty'    => false,
                        'parent'        => $idCatVal
                    ));

                    foreach ($categories as $category) {
                        $catDrp .= sprintf(
                            '<option value="%s">%s</option>',
                            '.' . $category->slug,
                            $category->name
                        );
                    }
                    $catDrp .= '</select>';
                }
            }

            echo $catDrp;
        echo '</form>';

        if ($topics) {
            echo '<div class="lesson-topics-container">';
            echo '<div class="cff_lesson-topics isotope">';
            foreach ($topics as $topic) {
                // $completed_class = ($topic['status']) ? 'topic-completed' : 'topic-notcompleted';				
                $completed_class = ($topic['status']) ? '' : '';
				$cpsturl = wp_get_attachment_url( get_post_thumbnail_id($topic['id']), 'thumbnail' ); 				if($cpsturl == ""){					$cpsturl = "https://demo.flippingfifty.com/wp-content/uploads/2023/12/Flipping50-logo.png";				}else{					$cpsturl = wp_get_attachment_url( get_post_thumbnail_id($topic['id']), 'thumbnail' ); 				}                echo '<div class="' . $completed_class . ' cff_lesson-topic ' . $topic['category'] . '" data-category="' . $topic['category'] . '"><a href="' . $topic['guid'] . '"><img src=" '. $cpsturl .'" /><span>' . $topic['title'] . '</span></a></div>';
            }
            echo '</div>';
            echo '</div>';
            echo '<div class="cff_pagination"></div>';
        } else {
        }
        echo '</div>';
    }

?>
   <style>        .main-lesson-topic {            margin: 10px;            margin: 0 auto;        }		.cff_lesson-topics.isotope {			display: flex;			flex-flow: wrap;		}        .cff_lesson-topic {            background: #008080;            overflow: hidden;			width: 31%;			margin: 10px 10px 0 0;        }        .cff_lesson-topic a {			color: #fff;            display: grid;            height: auto;            text-decoration: unset;            padding: 10px 10px 10px 10px;			cursor: pointer;			text-align: center;        }		.cff_lesson-topics.isotope img{			width: 100%;			min-height: 230px;			max-height: 230px;			object-fit: contain;		}        .cff_lesson-topic span {			width: 100%;			background: #9f246a;			padding: 10px 0;			margin-top: 10px;		}        .cff_pagination {            margin-top: 20px;        }        .cff_pagination a {            display: inline-block;            padding: 5px 10px;            margin-right: 5px;            border: 1px solid #ccc;            border-radius: 2px;            text-decoration: none;            color: #333;        }        .cff_pagination a.current {            background-color: #0073e6;            color: #fff;            border-color: #0073e6;        }        form.lesson-topic-search-form {            text-align: center;            margin-bottom: 10px;            display: flex;        }        form.lesson-topic-search-form input[type="text"] {            padding: 0px 10px !important;        }        form.lesson-topic-search-form input[type="text"],        form.lesson-topic-search-form select,        form.lesson-topic-search-form button {            height: 40px;            width: 20%;            margin: 0;            padding: 0;            margin-right: 10px;        }        button {            background: #9E246B;            border: 1px solid #9E246B;            color: #fff;        }        form.lesson-topic-search-form select {            height: 44px;        }        form.lesson-topic-search-form button {            width: 160px;            border-radius: 5px;        }        form.lesson-topic-search-form button:hover {            color: #9E246B;            background: transparent;        }        .cff_pagination {            display: flex;            flex-direction: row;            flex-wrap: wrap;            align-items: center;            column-gap: 5px;        }        .cff_pagination button {            border: 1px solid black;            background: transparent;            color: #9E246B;            padding: 5px 10px;        }        .cff_pagination button.cff_next,        .cff_pagination button.cff_prev {            background: #9E246B;            color: white;            border: 1px solid #9E246B;        }        button.cff_page.active-btn {            background: #9E246B;            color: #fff;        }        .multi-select-container {            display: inline-block;            position: relative;        }        .multi-select-menu {            position: absolute;            left: 0;            top: 0.8em;            float: left;            min-width: 100%;            background: #fff;            margin: 1em 0;            padding: 0.4em 0;            border: 1px solid #aaa;            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);            display: none;        }        .multi-select-menu input {            margin-right: 0.3em;            vertical-align: 0.1em;        }        .multi-select-button {            display: inline-block;            font-size: 0.875em;            padding: 0.5em 0.6em;            max-width: 20em;            white-space: nowrap;            overflow: hidden;            text-overflow: ellipsis;            vertical-align: -0.5em;            background-color: #fff;            border: 1px solid #767676;            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);            width: 250px;            margin: 0px 10px 0 0px;        }        .multi-select-button:after {            content: "";            display: inline-block;            width: 0;            height: 0;            border-style: solid;            border-width: 0.4em 0.4em 0 0.4em;            border-color: #999 transparent transparent transparent;            margin-left: 0.4em;            vertical-align: 0.1em;        }        label.multi-select-menuitem {            display: flex;            width: 100%;        }        .multi-select-container--open .multi-select-menu {            display: block;            z-index: 9;        }        .cff_hide-topic {            display: none;        }        .multi-select-container--open .multi-select-button:after {            border-width: 0 0.4em 0.4em 0.4em;            border-color: transparent transparent #999 transparent;        }			@media (max-width:768px) {				.cff_lesson-topic {				width: 46%;			}			.cff_lesson-topics.isotope img {				min-height: 100px;			}			.multi-select-container {				margin: 5px 0;			}			form.lesson-topic-search-form {				flex-flow: wrap;			}			form.lesson-topic-search-form input[type="text"], form.lesson-topic-search-form select, form.lesson-topic-search-form button {				width: 100%;			}			.multi-select-button {				width: 270px;				max-width: 30em;			}		}    </style>
<?php

    return ob_get_clean();
}
add_shortcode('learndash_lesson_topics', 'cff_learndash_lesson_topics_shortcode');

function cff_learndash_get_lesson_topics_list($lesson_id)
{
    $topics = [];
    
    $args = array(
        'post_type'      => 'sfwd-topic',
        'posts_per_page' => -1,
    );
    
    $query = new WP_Query( $args );
    
    if ( $query->have_posts() ){
        while ( $query->have_posts() ) {
            $query->the_post();
            $post_categories = wp_get_post_terms(get_the_ID(), 'ld_topic_category', array('fields' => 'slugs'));

            $topics[] = array(
                'id'        => get_the_ID(),
                'title'     => get_the_title(),
                'guid'      => get_permalink(get_the_ID()),
                // 'status'    => $lesson->completed,
                'category'  => implode(' ', $post_categories),
            );
        }
    }

    return $topics;
}

add_action('wp_ajax_cff_learndash_get_lesson_topics', 'cff_learndash_get_lesson_topics_list_ajax');
add_action('wp_ajax_nopriv_cff_learndash_get_lesson_topics', 'cff_learndash_get_lesson_topics_list_ajax');

function cff_learndash_get_lesson_topics_list_ajax($lesson_id)
{
    $data = '';
    $taxQueryCon = [];
    if( isset($_POST['catFilter']) && !empty($_POST['catFilter']) ){
        foreach ($_POST['catFilter'] as $key => $value) {
            if( $key == 0 ){
                $taxQueryCon[] = array(
                    'taxonomy' => 'ld_topic_category',
                    'field'    => 'slug',
                    'terms'    => $value,
                );
            }else{
                $taxQueryCon[] = array(
                    'relation' => 'AND',
                    array(
                        'taxonomy' => 'ld_topic_category',
                        'field'    => 'slug',
                        'terms'    => $value,
                    )
                );
            }
        }
    }

    $taxQuery = [];

    if( !empty($taxQueryCon) ){
        $taxQuery = array(
            'relation' => 'AND',
            $taxQueryCon
        );
    }

    $args = array(
        'post_type'         => 'sfwd-topic',
        'posts_per_page'    => -1,
        'tax_query'         => $taxQuery
    );
    
    $query = new WP_Query( $args );
    
    if ( $query->have_posts() ){
        while ( $query->have_posts() ) {
            $query->the_post();
            $post_categories = wp_get_post_terms(get_the_ID(), 'ld_topic_category', array('fields' => 'slugs'));

            $topic = array(
                'id'        => get_the_ID(),
                'title'     => get_the_title(),
                'guid'      => get_permalink(get_the_ID()),
                // 'status'    => $lesson->completed,
                'category'  => implode(' ', $post_categories),
            );

            $stringFound = true;
            
            if( isset($_POST['keyword']) && !empty($_POST['keyword']) ){               
                $stringFound = ( strpos($topic['title'], $_POST['keyword']) ) ? true : false;
            }

            if( $stringFound ){
                // $completed_class = ($topic['status']) ? 'topic-completed' : 'topic-notcompleted';
                $completed_class = ($topic['status']) ? '' : '';				$cpsturl = wp_get_attachment_url( get_post_thumbnail_id($topic['id']), 'thumbnail' ); 				if($cpsturl == ""){					$cpsturl = "https://demo.flippingfifty.com/wp-content/uploads/2023/12/Flipping50-logo.png";				}else{					$cpsturl = wp_get_attachment_url( get_post_thumbnail_id($topic['id']), 'thumbnail' ); 				}                echo '<div class="' . $completed_class . ' cff_lesson-topic ' . $topic['category'] . '" data-category="' . $topic['category'] . '"><a href="' . $topic['guid'] . '"><img src=" '. $cpsturl .'" /><span>' . $topic['title'] . '</span></a></div>';
            }
        }
    }else{
        $data = '<p class="cff_no-data">No Data Found!</p>';
    }

    echo $data;
    wp_die();
}