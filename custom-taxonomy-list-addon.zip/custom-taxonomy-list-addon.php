<?php
/*
Plugin Name: Custom Taxonomy List Addon
Description: A custom Elementor widget to filter content by taxonomy.
Version: 1.0
Author: Divyesh Sapariya
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

function enqueue_taxonomy_dropdown_script() {
    wp_register_style('ctla-widget-style', plugins_url( 'assets/ctla-widget-style.css', __FILE__ ) );
    wp_register_style('ctla-postlist-style', plugins_url( 'assets/ctla-postlist-style.css', __FILE__ ) );
    
    wp_register_script('ctla-widget-script', plugins_url( 'assets/ctla-widget-script.js', __FILE__ ), [ 'jquery' ] );
    wp_register_script('ctla-postlist-script', plugins_url( 'assets/ctla-postlist-script.js', __FILE__ ), [ 'jquery' ] );
    wp_localize_script('ctla-widget-script', 'ctalAjaxObj', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
    ));
}

add_action('wp_enqueue_scripts', 'enqueue_taxonomy_dropdown_script');

// Register the custom Elementor widget.
function elementor_test_widgets_registration( $widgets_manager ) {
	require_once( __DIR__ . '/classes/class.ctla-taxonomy-widget.php' );
	require_once( __DIR__ . '/classes/class.ctla-postlist-widget.php' );

	$widgets_manager->register( new \Elementor_Custom_Taxonomy_Filter_Widget() );
	$widgets_manager->register( new \Elementor_Custom_POSTLIST_Widget() );
}
add_action( 'elementor/widgets/register', 'elementor_test_widgets_registration' );

function ctla_get_taxonomy_items() {
    $itemList   = '';
    if ( isset($_POST['formobj']) && !empty($_POST['formobj']) ) {
        $formobj    = json_decode( str_replace( ' 2B23 ', '"', $_POST['formobj']), true );
        $taxonomy   = ( isset( $formobj['taxonomy'] ) && !empty( $formobj['taxonomy'] ) ) ? $formobj['taxonomy'] : '';
        $number     = ( isset( $formobj['limit_lists'] ) && !empty( $formobj['limit_lists'] ) ) ? $formobj['limit_lists'] : 1;
        $page       = isset( $_POST['page'] ) ? $_POST['page'] : 1;

        $args = array(
            'taxonomy'      => $taxonomy,
            'hide_empty'    => false,
            'number'        => $number,
            'offset'        => ($page - 1) * $number,
        );
        $terms = get_terms( $args );

        if (!empty($terms)) {
            foreach ($terms as $term) {
                $itemList .= sprintf(
                    '<li class="ctla_list-item"><a href="%s"><span>%s</span>%s</a></li>',
                    esc_url( get_term_link( $term ) ),
                    esc_html($term->name),
                    ( isset($formobj['show_term_count']) && $formobj['show_term_count'] == 'yes' ) ? '<span class="ctla_term-count">( '. esc_html($term->count) . ' )</span>' : ''
                );
            }
        }
    }else{
        $itemList .= '<p class="ctla_no-item">No items found.</p>';
    }

    echo $itemList;
    wp_die();
}

add_action('wp_ajax_ctla_get_taxonomy_items', 'ctla_get_taxonomy_items');
add_action('wp_ajax_nopriv_ctla_get_taxonomy_items', 'ctla_get_taxonomy_items');

function ctla_get_cpt_items() {
    $itemList   = '';
    if ( isset($_POST['formobj']) && !empty($_POST['formobj']) ) {
        $formobj    = json_decode( str_replace( ' 2B23 ', '"', $_POST['formobj']), true );
        $posttype   = ( isset( $formobj['posttype'] ) && !empty( $formobj['posttype'] ) ) ? $formobj['posttype'] : '';
        $number     = ( isset( $formobj['limit_lists'] ) && !empty( $formobj['limit_lists'] ) ) ? $formobj['limit_lists'] : 1;
        $page       = isset( $_POST['page'] ) ? $_POST['page'] : 1;

        $args = array(
            'post_type' => $posttype,
            'paged'     => $page
        );
        
        if ( $number > 0 ) {
            $args['posts_per_page'] = $number;
        }

        $cusQury = new WP_Query( $args );

        if (!empty($cusQury)) {
            if ($cusQury->have_posts()){
                while ($cusQury->have_posts()) :
                    $cusQury->the_post();
                    
                    $doctorShort = '';                   
                    $termLink = '';                   
                    $terms = wp_get_post_terms( get_the_ID(), 'doctor_country' );

                    if (!empty($terms)) {
                        foreach ($terms as $term) {
                            $termLink = sprintf(
                                '<div class="ctla_col-5">
                                    <div class="ctla_term-name ctla-text-center">
                                        <a href="%s" class="ctla_term-link">%s</a>
                                    </div>
                                </div>',
                                get_term_link($term),
                                $term->name
                            );

                            $doctorShort = $term->name . ' is one of the Best Doctor in Kettering. Explore more details about ' . $term->name . '.';
                        }
                    }
                    
                    $termLinkNxt = '';
                    $terms = wp_get_post_terms( get_the_ID(), 'doctor_state' );

                    if (!empty($terms)) {
                        foreach ($terms as $term) {
                            $termLinkNxt = sprintf(
                                '<div class="ctla_col-5">
                                    <div class="ctla_term-name ctla-text-center">
                                        <a href="%s" class="ctla_term-link">%s</a>
                                    </div>
                                </div>',
                                get_term_link($term),
                                $term->name
                            );
                        }
                    }

                    $termLink .= $termLinkNxt;

                    $itemList .= sprintf(
                        '<div class="ctla_col-3">
                            <div class="ctla_widget-box">
                                <div class="ctla_col-row p-10">
                                    <div class="ctla_col-3">
                                        <div class="ctla_img-parent">
                                            <img src="%s" alt="%s" width="150" height="auto" />
                                        </div>
                                    </div>
                                    <div class="ctla_col-7 p-10">
                                        <h3>%s</h3>
                                        <p class="ctla_mb-10">%s</p>
                                        <p>%s</p>
                                    </div>
                                </div>
                                <div class="ctla_row-expand">
                                    <div class="ctla_col-row ctla-gap">
                                        %s
                                    </div>
                                    <div class="ctla_col-row">
                                        <div class="ctla_col-10">
                                            <p>%s</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="ctla_col-row ctla_box-footer ctla_space-between">
                                    <div class="ctla_col-5">
                                        <a href="%s" class="ctla_post-link">View Details</a>
                                    </div>
                                    <div class="ctla_col-5 ctla-text-end">
                                        <a href="javascript:void(0);" class="ctla_post-expand">Expand</a>
                                    </div>
                                </div>
                            </div>
                        </div>',
                        get_the_post_thumbnail_url( get_the_ID() ),
                        esc_html( get_the_title() ),
                        esc_html( get_the_title() ),
                        $doctorShort,
                        get_field( 'doctor_experience', get_the_ID() ),
                        $termLink,
                        get_field( 'doctor_about', get_the_ID() ),
                        esc_url( get_the_permalink())
                    );
                endwhile;
            }
        }
    }else{
        $itemList .= '<p class="ctla_no-item">No items found.</p>';
    }

    echo $itemList;
    wp_die();
}

add_action('wp_ajax_ctla_get_cpt_items', 'ctla_get_cpt_items');
add_action('wp_ajax_nopriv_ctla_get_cpt_items', 'ctla_get_cpt_items');
