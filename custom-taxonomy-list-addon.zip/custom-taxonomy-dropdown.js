jQuery(document).ready(function($) {
    $('#elementor-control-select2-show_items').on('change', function() {
        var selectedTaxonomy = $('#elementor-control-select-taxonomy_filter').val();
        $.ajax({
            url: customTaxonomyDropdown.ajaxurl,
            type: 'POST',
            data: {
                action: 'get_taxonomy_items',
                taxonomy: selectedTaxonomy,
            },
            success: function(response) {
                var items = JSON.parse(response);

                $('#elementor-control-select2-show_items').empty();
                $.each(items, function(key, value) {
                    $('#elementor-control-select2-show_items').append($('<option>', {
                        value: key,
                        text: value,
                    }));
                });
            },
        });
    });
});
