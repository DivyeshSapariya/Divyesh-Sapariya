jQuery(document).ready(function($) {
    
    jQuery(document).on( 'click', 'a.ctla_post-expand', function(e,v){
        jQuery( this ).parents( '.ctla_widget-box' ).find('.ctla_row-expand').toggle( 'slow' );
        if( jQuery( this ).text() == 'Expand' ){
            jQuery( this ).text( 'Collapse' );
        }else{
            jQuery( this ).text( 'Expand' );
        }
    });

    jQuery(document).find('button.ctla_load-more').on('click', function() {
        var formobj = jQuery(this).attr('data-formobj');        
        var curpage = parseInt(jQuery(this).attr('data-currpage'));
        var page = parseInt(jQuery(this).attr('data-loadpage'));

        let thisObj = jQuery(this);

        jQuery.ajax({
            url: ctalAjaxObj.ajaxurl,
            type: 'POST',
            data: {
                action: 'ctla_get_cpt_items',
                page: curpage,
                formobj: formobj,
            },
            success: function(response) {
                curpage++
                thisObj.parents('.ctla_row-postlist').find('button.ctla_load-more').attr('data-currpage', curpage );

                if (response) {
                    thisObj.parents('.ctla_row-postlist').find('.ctla_cpt-widget').append(response);
                }

                if( curpage > page ){
                    thisObj.parents('.ctla_row-postlist').find('button.ctla_btn-load').addClass('ctla_btn-hide');
                }else{
                    thisObj.parents('.ctla_row-postlist').find('button.ctla_btn-load').removeClass('ctla_btn-hide');
                }
            },
        });
    });
});