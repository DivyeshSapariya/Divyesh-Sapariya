jQuery(document).ready(function($) {
    
    jQuery(document).find('button.ctla_load-more-terms').on('click', function() {
        var formobj = jQuery(this).attr('data-formobj');        
        var curpage = parseInt(jQuery(this).attr('data-currpage'));
        var page = parseInt(jQuery(this).attr('data-loadpage'));

        let thisObj = jQuery(this);

        jQuery.ajax({
            url: ctalAjaxObj.ajaxurl,
            type: 'POST',
            data: {
                action: 'ctla_get_taxonomy_items',
                page: curpage,
                formobj: formobj,
            },
            success: function(response) {
                curpage++
                thisObj.parents('.ctla_widget-block').find('button.ctla_load-more-terms').attr('data-currpage', curpage );

                if (response) {
                    thisObj.parents('.ctla_widget-block').find('.ctla_cat-widget').append(response);
                }

                if( curpage > page ){
                    thisObj.parents('.ctla_widget-block').find('button.ctla_load-more-terms').addClass('ctla_btn-hide');
                }else{
                    thisObj.parents('.ctla_widget-block').find('button.ctla_load-more-terms').removeClass('ctla_btn-hide');
                }
            },
        });
    });
});