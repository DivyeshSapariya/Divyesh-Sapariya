<?php


if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Elementor_Custom_POSTLIST_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'ctla_postlist_filter';
    }

    public function get_title() {
        return __('Custom Post List', 'elementor-custom-taxonomy-filter');
    }

    public function get_icon() {
        return 'eicon-dropdown'; // You can choose a different icon.
    }

    public function get_categories() {
        return ['basic']; // Choose an appropriate category.
    }

    public function get_script_depends() {
		return [ 'ctla-postlist-script' ];
	}

	public function get_style_depends() {
		return [ 'ctla-postlist-style' ];
	}

    protected function _register_controls() {

        $this->start_controls_section(
            'section_taxonomy_filter',
            [
                'label' => __('Taxonomy Filter', 'elementor-custom-taxonomy-filter'),
            ]
        );

        $this->add_control(
            'taxonomy_filter',
            [
                'label' => __('Select Post type', 'elementor-custom-taxonomy-filter'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $this->get_post_types_options(),
            ]
        );

        $this->add_control(
            'limit_lists',
            [
                'label' => __('Set Limits', 'elementor-custom-taxonomy-filter'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
				'max' => 100,
				'step' => 1,
				'default' => 12
            ]
        );
        
        $this->add_control(
            'per_row_limit',
            [
                'label' => __('Per Row Limit', 'elementor-custom-taxonomy-filter'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
				'max' => 10,
				'step' => 1,
				'default' => 4
            ]
        );
        
        $this->add_control(
            'tab_per_row_limit',
            [
                'label' => __('Tablet - Per Row Limit', 'elementor-custom-taxonomy-filter'),
                'description' => esc_html__( 'Below 991px', 'elementor-custom-taxonomy-filter' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
				'max' => 10,
				'step' => 1,
				'default' => 1
            ]
        );
        
        $this->add_control(
            'mobile_per_row_limit',
            [
                'label' => __('Mobile - Per Row Limit', 'elementor-custom-taxonomy-filter'),
                'description' => esc_html__( 'Below 786px', 'elementor-custom-taxonomy-filter' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
				'max' => 10,
				'step' => 1,
				'default' => 1
            ]
        );

        $this->end_controls_section();

    }

    // Retrieving JS Settings
    protected function ______content_template() {
		?>
		<# if ( settings.list.length ) { #>
			<ul>
			<# _.each( settings.list, function( item ) { #>
				<li>{{{ item }}}</li>
			<# } ) #>
			</ul>
		<# } #>
		<?php
	}

    // Retrieving PHP Settings
    protected function render() {
        $itemList = '';
        $settings = $this->get_settings_for_display();

        $postType  = isset( $settings['taxonomy_filter'] ) ? $settings['taxonomy_filter'] : '';
        $limit_lists        = ( isset( $settings['limit_lists'] ) && $settings['limit_lists'] > 0 ) ? $settings['limit_lists'] : 8;
        $ctla_per_row       = ( isset( $settings['per_row_limit'] ) && $settings['per_row_limit'] > 0 ) ? $settings['per_row_limit'] : 4;
        $mobile_per_limit   = ( isset( $settings['mobile_per_row_limit'] ) && $settings['mobile_per_row_limit'] > 0 ) ? $settings['mobile_per_row_limit'] : 1;
        $tab_per_limit      = ( isset( $settings['tab_per_row_limit'] ) && $settings['tab_per_row_limit'] > 0 ) ? $settings['tab_per_row_limit'] : 3;
        $show_empty_terms   = isset( $settings['show_empty_terms'] ) ? $settings['show_empty_terms'] : false;
        $show_term_count    = isset( $settings['show_term_count'] ) ? $settings['show_term_count'] : true;

       // Check if a taxonomy is selected.
        if (!empty($postType)) {
            $query_args = array(
                'post_type' => $postType,
                'paged'     => false
            );
            
            if ( $limit_lists > 0 ) {
                $query_args['posts_per_page'] = $limit_lists;
            }

            $cusQury = new WP_Query( $query_args );

            if (!empty($cusQury)) {
                if ($cusQury->have_posts()){
                    while ($cusQury->have_posts()) :
                        $cusQury->the_post();
                        
                        $doctorShort = '';                   
                        $termLink = '';                   
                        $terms = wp_get_post_terms( get_the_ID(), 'doctor_country' );

                        if (!empty($terms)) {
                            foreach ($terms as $term) {
                                $termLink = sprintf(
                                    '<div class="ctla_col-5">
                                        <div class="ctla_term-name ctla-text-center">
                                            <a href="%s" class="ctla_term-link">%s</a>
                                        </div>
                                    </div>',
                                    get_term_link($term),
                                    $term->name
                                );

                                $doctorShort = $term->name . ' is one of the Best Doctor in Kettering. Explore more details about ' . $term->name . '.';
                            }
                        }
                        
                        $termLinkNxt = '';
                        $terms = wp_get_post_terms( get_the_ID(), 'doctor_state' );

                        if (!empty($terms)) {
                            foreach ($terms as $term) {
                                $termLinkNxt = sprintf(
                                    '<div class="ctla_col-5">
                                        <div class="ctla_term-name ctla-text-center">
                                            <a href="%s" class="ctla_term-link">%s</a>
                                        </div>
                                    </div>',
                                    get_term_link($term),
                                    $term->name
                                );
                            }
                        }

                        $termLink .= $termLinkNxt;

                        $itemList .= sprintf(
                            '<div class="ctla_col-3">
                                <div class="ctla_widget-box">
                                    <div class="ctla_col-row p-10 ctla_mb-flex">
                                        <div class="ctla_col-3">
                                            <div class="ctla_img-parent">
                                                <img src="%s" alt="%s" width="150" height="auto" />
                                            </div>
                                        </div>
                                        <div class="ctla_col-7 p-10">
                                            <h3>%s</h3>
                                            <p class="ctla_mb-10">%s</p>
                                            <p>%s</p>
                                        </div>
                                    </div>
                                    <div class="ctla_row-expand">
                                        <div class="ctla_col-row ctla-gap">
                                            %s
                                        </div>
                                        <div class="ctla_col-row">
                                            <div class="ctla_col-10">
                                                <p>%s</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ctla_col-row ctla_box-footer ctla_space-between">
                                        <div class="ctla_col-5">
                                            <a href="%s" class="ctla_post-link">View Details</a>
                                        </div>
                                        <div class="ctla_col-5 ctla-text-end">
                                            <a href="javascript:void(0);" class="ctla_post-expand">Expand</a>
                                        </div>
                                    </div>
                                </div>
                            </div>',
                            get_the_post_thumbnail_url( get_the_ID() ),
                            esc_html( get_the_title() ),
                            esc_html( get_the_title() ),
                            $doctorShort,
                            get_field( 'doctor_experience', get_the_ID() ),
                            $termLink,
                            get_field( 'doctor_about', get_the_ID() ),
                            esc_url( get_the_permalink())
                        );
                    endwhile;
                }
            } else {
                $itemList .= '<p class="ctla_no-item">No items found.</p>';
            }
        } else {
            $itemList .= '<p class="ctla_no-select">Please select a taxonomy.</p>';
        }

        $widget_id = $this->get_id();

        echo sprintf(
            '<style>
            .elementor-element.elementor-element-%s .ctla_col-row.ctla-gap > .ctla_col-3 {
                width: calc(%s - 20px);
            }
            @media (max-width: 991px) {    
                .elementor-element.elementor-element-%s .ctla_col-row.ctla-gap > .ctla_col-3 {
                    width: calc( %s - 20px );
                }
            },
            @media (max-width: 768px) {    
                .elementor-element.elementor-element-%s .ctla_col-row.ctla-gap > .ctla_col-3 {
                    width: calc( %s - 20px );
                }
            }
            </style>
            <section class="ctla_row-postlist%s">
                <div class="ctla_col-row ctla-gap ctla_cpt-widget">
                    %s
                </div>
                <div class="ctla_btn-load %s">
                    <button class="%s" data-formobj="%s" data-currpage="2" data-loadpage="%s">Load More</button>
                </div>
            </section>',
            $widget_id,
            ( 100 / $ctla_per_row ) . '%',
            $widget_id,
            ( 100 / $tab_per_limit ) . '%',
            $widget_id,
            ( 100 / $mobile_per_limit ) . '%',
            isset($settings['class']) ? ' ' . esc_attr( $settings['class'] ) : '',
            $itemList,
            ( $cusQury->max_num_pages > 1 ) ? 'ctla_load-hide' : '',
            ( $cusQury->max_num_pages > 1 ) ? 'ctla_load-more' : '',
            str_replace( '"', ' 2B23 ', json_encode( array(
                'posttype'          => $postType,
                'limit_lists'       => $limit_lists
            ) ) ),
            $cusQury->max_num_pages        
        );
    }

    private function get_post_types_options() {
        $posttype_opts  = [];
        $post_types = get_post_types([], 'objects');
        
        foreach ($post_types as $posttype) {
            $posttype_opts[$posttype->name] = $posttype->label;
        }

        return $posttype_opts;
    }
}