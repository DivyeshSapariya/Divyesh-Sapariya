<?php


if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Elementor_Custom_Taxonomy_Filter_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'custom_taxonomy_filter';
    }

    public function get_title() {
        return __('Custom Taxonomy Filter', 'elementor-custom-taxonomy-filter');
    }

    public function get_icon() {
        return 'eicon-dropdown'; // You can choose a different icon.
    }

    public function get_categories() {
        return ['basic']; // Choose an appropriate category.
    }

    public function get_script_depends() {
		return [ 'ctla-widget-script' ];
	}

	public function get_style_depends() {
		return [ 'ctla-widget-style' ];
	}

    protected function _register_controls() {

        $this->start_controls_section(
            'section_taxonomy_filter',
            [
                'label' => __('Taxonomy Filter', 'elementor-custom-taxonomy-filter'),
            ]
        );

        $this->add_control(
            'taxonomy_filter',
            [
                'label' => __('Select Taxonomy', 'elementor-custom-taxonomy-filter'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $this->get_taxonomy_options(),
            ]
        );

        $this->add_control(
            'limit_lists',
            [
                'label' => __('Set Limits', 'elementor-custom-taxonomy-filter'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
				'max' => 100,
				'step' => 1,
				'default' => 12
            ]
        );
        
        $this->add_control(
            'per_row_limit',
            [
                'label' => __('Per Row Limit', 'elementor-custom-taxonomy-filter'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
				'max' => 10,
				'step' => 1,
				'default' => 4
            ]
        );
        
        $this->add_control(
            'tab_per_row_limit',
            [
                'label' => __('Tablet - Per Row Limit', 'elementor-custom-taxonomy-filter'),
                'description' => esc_html__( 'Below 991px', 'elementor-custom-taxonomy-filter' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
				'max' => 10,
				'step' => 1,
				'default' => 1
            ]
        );
        
        $this->add_control(
            'mobile_per_row_limit',
            [
                'label' => __('Mobile - Per Row Limit', 'elementor-custom-taxonomy-filter'),
                'description' => esc_html__( 'Below 786px', 'elementor-custom-taxonomy-filter' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
				'max' => 10,
				'step' => 1,
				'default' => 1
            ]
        );

        // Add a control to show/hide empty terms.
        $this->add_control(
            'show_empty_terms',
            [
                'label' => __('Hide Empty Terms', 'elementor-custom-taxonomy-filter'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'elementor-ctla-widget' ),
                'label_off' => __( 'Hide', 'elementor-ctla-widget' ),
                'return_value' => 'true',
                'default' => 'true',
            ]
        );

        $this->add_control(
			'show_term_count',
			[
				'label' => esc_html__( 'Show Term Count', 'elementor-ctla-widget' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'elementor-ctla-widget' ),
				'label_off' => esc_html__( 'Hide', 'elementor-ctla-widget' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'box_background_color',
			[
				'label' => esc_html__( 'Box Background Color', 'elementor-ctla-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'box_text_color',
			[
				'label' => esc_html__( 'Text Color', 'elementor-ctla-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#000000',
				'selectors' => [
					'{{WRAPPER}} ul.ctla_cat-widget li.ctla_list-item a span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} ul.ctla_cat-widget li.ctla_list-item',
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
			'box_background_hover_color',
			[
				'label' => esc_html__( 'Box Background Hover Color', 'elementor-ctla-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'box_hover_text_color',
			[
				'label' => esc_html__( 'Hover Text Color', 'elementor-ctla-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} ul.ctla_cat-widget li.ctla_list-item a:hover span' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background_hover',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} ul.ctla_cat-widget li.ctla_list-item a::before',
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
			'btn_box_setting',
			[
				'label' => esc_html__( 'Button Settings', 'elementor-ctla-widget' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
			'btn_box_text_color',
			[
				'label' => esc_html__( 'Button Text Color', 'elementor-ctla-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ctla_widget-button button.ctla_load-more-terms' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'btn_box_hover_text_color',
			[
				'label' => esc_html__( 'Button Hover Text Color', 'elementor-ctla-widget' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .ctla_widget-button button.ctla_load-more-terms:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'button_background',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ctla_widget-button button.ctla_load-more-terms',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'button_background_hover',
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .ctla_widget-button button.ctla_load-more-terms:hover',
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'btn_border',
				'selector' => '{{WRAPPER}} .ctla_widget-button button.ctla_load-more-terms',
			]
		);

        $this->add_control(
            'btn_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'textdomain' ),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'selectors' => [
                    '{{WRAPPER}} .ctla_widget-button button.ctla_load-more-terms' => 'border-radius: {{VALUE}}px'
                ],
            ]
        );

		$this->end_controls_section();

    }

    // Retrieving JS Settings
    protected function ______content_template() {
		?>
		<# if ( settings.list.length ) { #>
			<ul>
			<# _.each( settings.list, function( item ) { #>
				<li>{{{ item }}}</li>
			<# } ) #>
			</ul>
		<# } #>
		<?php
	}

    // Retrieving PHP Settings
    protected function render() {
        $itemList = '';
        $settings = $this->get_settings_for_display();

        $selected_taxonomy  = isset( $settings['taxonomy_filter'] ) ? $settings['taxonomy_filter'] : '';
        $limit_lists        = ( isset( $settings['limit_lists'] ) && $settings['limit_lists'] > 0 ) ? $settings['limit_lists'] : 8;
        $ctla_per_row       = ( isset( $settings['per_row_limit'] ) && $settings['per_row_limit'] > 0 ) ? $settings['per_row_limit'] : 4;
        $mobile_per_limit   = ( isset( $settings['mobile_per_row_limit'] ) && $settings['mobile_per_row_limit'] > 0 ) ? $settings['mobile_per_row_limit'] : 1;
        $tab_per_limit      = ( isset( $settings['tab_per_row_limit'] ) && $settings['tab_per_row_limit'] > 0 ) ? $settings['tab_per_row_limit'] : 3;
        $show_empty_terms   = isset( $settings['show_empty_terms'] ) ? $settings['show_empty_terms'] : false;
        $show_term_count    = isset( $settings['show_term_count'] ) ? $settings['show_term_count'] : true;

       // Check if a taxonomy is selected.
        if (!empty($selected_taxonomy)) {
            $query_args = array(
                'taxonomy'      => $selected_taxonomy,
                'hide_empty'    => false
            );
    
            // Add 'hide_empty' parameter based on the show_empty_terms control.
            if ( $show_empty_terms ) {
                $query_args['hide_empty'] = true;
            }
            
            if ( $limit_lists > 0 ) {
                $query_args['number'] = $limit_lists;
            }

            $taxonomy_terms = get_terms($query_args);
            $total_terms    = wp_count_terms($query_args);

            // Check if there are terms to display.
            if (!empty($taxonomy_terms)) {
                foreach ($taxonomy_terms as $term) {
                    $itemList .= sprintf(
                        '<li class="ctla_list-item"><a href="%s"><span>%s</span>%s</a></li>',
                        esc_url( get_term_link( $term ) ),
                        esc_html($term->name),
                        ( $show_term_count ) ? '<span class="ctla_term-count">( '. esc_html($term->count) . ' )</span>' : ''
                    );
                }
            } else {
                $itemList .= '<p class="ctla_no-item">No items found.</p>';
            }
        } else {
            $itemList .= '<p class="ctla_no-select">Please select a taxonomy.</p>';
        }

        // :root {
        //     --ctla_per_row: %s;
        //     --tb_ctla_per_row: %s;
        //     --mb_ctla_per_row: %s;
        // }
        $widget_id = $this->get_id();

        echo sprintf(
            '<style>
            .elementor-element.elementor-element-%s ul.ctla_cat-widget li.ctla_list-item {
                background: #ffffff;
                color: #000000;
                width: calc(%s - 20px);
                max-height: 100px;
                height: 100px;
                border-radius: 10px;
                box-shadow: rgba(0, 0, 0, 0.25) 0px 0.0625em 0.0625em, rgba(0, 0, 0, 0.25) 0px 0.125em 0.5em, rgba(255, 255, 255, 0.1) 0px 0px 0px 1px inset;
            }
            @media (max-width: 991px) {    
                .elementor-element.elementor-element-%s ul.ctla_cat-widget li.ctla_list-item {
                    width: calc( %s - 20px );
                }
            },
            @media (max-width: 768px) {    
                .elementor-element.elementor-element-%s ul.ctla_cat-widget li.ctla_list-item {
                    width: calc( %s - 20px );
                }
            }
            </style>
            <div class="ctla_widget-block%s">
                <ul class="ctla_cat-widget">%s</ul>
                <div class="ctla_widget-button %s">
                    <button class="ctla_load-more-terms" data-formobj="%s" data-loadlimit="%s" data-loadtype="%s" data-currpage="2" data-loadpage="%s">Load More</button>
                </div>
            </div>',
            $widget_id,
            ( 100 / $ctla_per_row ) . '%',
            $widget_id,
            ( 100 / $tab_per_limit ) . '%',
            $widget_id,
            ( 100 / $mobile_per_limit ) . '%',
            isset($settings['class']) ? ' ' . esc_attr( $settings['class'] ) : '',
            $itemList,
            ( ceil( $total_terms / $limit_lists ) <= 1 ) ? 'ctla_btn-hide' : '',
            str_replace( '"', ' 2B23 ', json_encode( array(
                'taxonomy'          => $selected_taxonomy,
                'limit_lists'       => $limit_lists,
                'total_terms'       => $total_terms,
                'show_term_count'   => $show_term_count
            ) ) ),
            $limit_lists,
            $selected_taxonomy,
            ( !empty($total_terms) && $total_terms > 0 ) ? ceil( $total_terms / $limit_lists ) : 0
        );
    }

    private function get_taxonomy_options() {
        $taxonomy_opts  = [];
        $taxonomies     = get_taxonomies(['public' => true], 'objects');

        foreach ($taxonomies as $taxonomy) {
            $taxonomy_opts[$taxonomy->name] = $taxonomy->label;
        }

        return $taxonomy_opts;
    }
}